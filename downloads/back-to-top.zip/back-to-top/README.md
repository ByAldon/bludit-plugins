# Back To Top

A customizable button to smoothly scroll back to the top of the page.

[![Build Status](https://img.shields.io/badge/dynamic/json?url=https%3A%2F%2Fraw.githubusercontent.com%2FByAldon%2Fbludit-plugins%2Fmain%2Fsources%2Fback-to-top%2Fmetadata.json&query=%24.version&label=build&color=green&style=for-the-badge)](https://github.com/ByAldon/bludit-plugins/blob/main/sources/back-to-top/metadata.json)
[![Download](https://img.shields.io/badge/download-back%20to%20top-blue?style=for-the-badge)](https://github.com/ByAldon/bludit-plugins/tree/main/downloads)
