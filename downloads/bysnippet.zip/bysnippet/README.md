# BySnippet

Transforms URL shortcodes into link cards.

===================================================

This was a personal project. But you are welcome to use it whenever you want.

If you found any issues please report it on [the issues page](https://github.com/ByAldon/bludit-plugins/issues).

===================================================

[![Download](https://img.shields.io/badge/download-bysnippet-blue?style=for-the-badge)](https://github.com/ByAldon/bludit-plugins/tree/main/downloads)
[![Build](https://img.shields.io/badge/dynamic/json?url=https%3A%2F%2Fraw.githubusercontent.com%2FByAldon%2Fbludit-plugins%2Fmain%2Fsources%2Fbysnippet%2Fmetadata.json&query=%24.version&label=build&color=green&style=for-the-badge)](https://github.com/ByAldon/bludit-plugins/blob/main/sources/bysnippet/metadata.json)
[![Bludit](https://img.shields.io/badge/dynamic/json?url=https%3A%2F%2Fraw.githubusercontent.com%2FByAldon%2Fbludit-plugins%2Fmain%2Fsources%2Fbysnippet%2Fmetadata.json&query=%24.compatible&label=bludit&color=orange&style=for-the-badge)](https://github.com/ByAldon/bludit-plugins/blob/main/sources/bysnippet/metadata.json)