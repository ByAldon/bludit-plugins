# Session Manager (Early Acces)

Adjust the login session duration or enforce session termination.

===================================================

This is still a early acces plugin.<br>
This means that this plugin still may contain bugs.<br>
Please use [issues](https://github.com/ByAldon/bludit-plugins/issues) to let me know about any bugs

===================================================

[![Build Status](https://img.shields.io/badge/dynamic/json?url=https%3A%2F%2Fraw.githubusercontent.com%2FByAldon%2Fbludit-plugins%2Fmain%2Fsources%2Fsession-manager%2Fmetadata.json&query=%24.version&label=build&color=green&style=for-the-badge)](https://github.com/ByAldon/bludit-plugins/blob/main/sources/session-manager/metadata.json)
[![Download](https://img.shields.io/badge/download-Session--Manager-blue?style=for-the-badge)](https://github.com/ByAldon/bludit-plugins/tree/main/downloads)